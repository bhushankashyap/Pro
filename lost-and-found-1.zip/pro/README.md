# 🔍 Lost & Found Web App

A full-stack Lost & Found platform built with **React + Vite** (frontend) and **Node.js + Express + SQLite** (backend).

---

## 🚀 Quick Start

### Prerequisites
- Node.js v18+ installed
- npm or yarn

---

### 1. Backend Setup

```bash
cd backend
npm install
npm start
```

Server runs at: **http://localhost:5000**

**Default Admin Credentials:**
- Email: `admin@lostfound.com`
- Password: `admin123`

---

### 2. Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

App runs at: **http://localhost:5173**

---

## 📁 Project Structure

```
lost-and-found/
├── backend/
│   ├── database/
│   │   └── db.js          # SQLite DB + schema
│   ├── middleware/
│   │   └── auth.js        # JWT authentication
│   ├── routes/
│   │   ├── auth.js        # Register, login, profile
│   │   ├── items.js       # Lost/found items CRUD
│   │   ├── claims.js      # Claims management
│   │   └── misc.js        # Messages, notifs, admin
│   ├── uploads/           # Uploaded images (auto-created)
│   └── server.js          # Express app entry
│
└── frontend/
    └── src/
        ├── components/
        │   ├── Navbar.jsx
        │   └── ItemCard.jsx
        ├── context/
        │   ├── AuthContext.jsx
        │   └── ThemeContext.jsx
        ├── pages/
        │   ├── Home.jsx
        │   ├── Login.jsx
        │   ├── Register.jsx
        │   ├── Items.jsx          # Browse with filters
        │   ├── ItemDetail.jsx     # Full item view + claim
        │   ├── ItemForm.jsx       # Report lost/found
        │   ├── Dashboard.jsx      # User dashboard
        │   ├── Profile.jsx
        │   ├── Admin.jsx          # Admin panel
        │   └── ForgotPassword.jsx
        ├── utils/
        │   └── api.js             # Axios instance
        ├── App.jsx
        └── main.jsx
```

---

## ✨ Features

### 👤 User Features
- ✅ Register / Login / Forgot Password
- ✅ Report Lost or Found items with photos
- ✅ Browse & filter items (type, category, location, date)
- ✅ Claim items with proof submission
- ✅ Track claim status (Pending / Approved / Rejected)
- ✅ Bookmark / Save items
- ✅ In-app notifications (claim updates, matches, messages)
- ✅ Messaging system
- ✅ QR Code generation for items
- ✅ AI-style keyword matching for suggestions
- ✅ Dark mode toggle
- ✅ Mobile responsive design
- ✅ Profile management & password change

### 🛡️ Admin Features
- ✅ Admin dashboard with stats
- ✅ Manage all users (block/delete)
- ✅ Manage all items (resolve/remove)
- ✅ Manage all claims (approve/reject)
- ✅ Handle reported/flagged content
- ✅ Category management (add/delete)
- ✅ Send announcements to all users
- ✅ Activity logs viewer

---

## 🗄️ Database

SQLite database is auto-created at `backend/lostfound.db` on first run.

**Tables:** users, items, item_images, categories, claims, messages, bookmarks, notifications, activity_logs, reported_items

---

## 🔧 Environment Variables (optional)

Create `backend/.env`:
```
PORT=5000
JWT_SECRET=your_custom_secret
FRONTEND_URL=http://localhost:5173
```

---

## 🎓 Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18, Vite, Tailwind CSS |
| Backend | Node.js, Express.js |
| Database | SQLite (better-sqlite3) |
| Auth | JWT (jsonwebtoken) + bcryptjs |
| File Upload | Multer |
| QR Code | qrcode |
| UI Icons | Lucide React |
| Toast | React Hot Toast |

---

## 📧 Default Admin

| Field | Value |
|-------|-------|
| Email | admin@lostfound.com |
| Password | admin123 |

---

*Built for college project demonstration. Happy coding! 🚀*
