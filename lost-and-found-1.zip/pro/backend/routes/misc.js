const express = require('express');
const { db } = require('../database/db');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

const router = express.Router();

// ===== MESSAGES =====
router.get('/messages', authMiddleware, (req, res) => {
  const threads = db.prepare(`
    SELECT m.*, 
           s.name as sender_name, s.email as sender_email,
           r.name as receiver_name, r.email as receiver_email,
           i.title as item_title, i.uuid as item_uuid
    FROM messages m
    JOIN users s ON m.sender_id = s.id
    JOIN users r ON m.receiver_id = r.id
    LEFT JOIN items i ON m.item_id = i.id
    WHERE m.sender_id = ? OR m.receiver_id = ?
    ORDER BY m.created_at DESC
  `).all(req.user.id, req.user.id);
  res.json(threads);
});

router.post('/messages', authMiddleware, (req, res) => {
  const { receiver_id, content, item_id } = req.body;
  if (!receiver_id || !content) return res.status(400).json({ error: 'Receiver and content required' });
  const result = db.prepare('INSERT INTO messages (sender_id, receiver_id, content, item_id) VALUES (?,?,?,?)').run(req.user.id, receiver_id, content, item_id || null);
  db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)`).run(receiver_id, 'New Message', `${req.user.name} sent you a message`, 'message');
  res.json(db.prepare('SELECT * FROM messages WHERE id = ?').get(result.lastInsertRowid));
});

router.put('/messages/:id/read', authMiddleware, (req, res) => {
  db.prepare('UPDATE messages SET is_read = 1 WHERE id = ? AND receiver_id = ?').run(req.params.id, req.user.id);
  res.json({ ok: true });
});

// ===== NOTIFICATIONS =====
router.get('/notifications', authMiddleware, (req, res) => {
  const notifs = db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.user.id);
  res.json(notifs);
});

router.put('/notifications/read-all', authMiddleware, (req, res) => {
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.user.id);
  res.json({ ok: true });
});

router.put('/notifications/:id/read', authMiddleware, (req, res) => {
  db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ ok: true });
});

// ===== CATEGORIES =====
router.get('/categories', (req, res) => {
  const cats = db.prepare('SELECT * FROM categories ORDER BY name').all();
  res.json(cats);
});

router.post('/categories', adminMiddleware, (req, res) => {
  const { name, icon } = req.body;
  const result = db.prepare('INSERT INTO categories (name, icon) VALUES (?,?)').run(name, icon || '📦');
  res.json(db.prepare('SELECT * FROM categories WHERE id = ?').get(result.lastInsertRowid));
});

router.put('/categories/:id', adminMiddleware, (req, res) => {
  const { name, icon } = req.body;
  db.prepare('UPDATE categories SET name=?, icon=? WHERE id=?').run(name, icon, req.params.id);
  res.json(db.prepare('SELECT * FROM categories WHERE id = ?').get(req.params.id));
});

router.delete('/categories/:id', adminMiddleware, (req, res) => {
  db.prepare('DELETE FROM categories WHERE id = ?').run(req.params.id);
  res.json({ message: 'Category deleted' });
});

// ===== ADMIN ROUTES =====
router.get('/admin/dashboard', adminMiddleware, (req, res) => {
  const stats = {
    total_users: db.prepare('SELECT COUNT(*) as c FROM users WHERE role != ?').get('admin').c,
    total_lost: db.prepare("SELECT COUNT(*) as c FROM items WHERE type='lost' AND status!='removed'").get().c,
    total_found: db.prepare("SELECT COUNT(*) as c FROM items WHERE type='found' AND status!='removed'").get().c,
    total_claims: db.prepare('SELECT COUNT(*) as c FROM claims').get().c,
    pending_claims: db.prepare("SELECT COUNT(*) as c FROM claims WHERE status='pending'").get().c,
    resolved_items: db.prepare("SELECT COUNT(*) as c FROM items WHERE status='resolved'").get().c,
    reported_items: db.prepare("SELECT COUNT(*) as c FROM reported_items WHERE status='pending'").get().c,
    recent_items: db.prepare(`SELECT i.*, u.name as user_name, c.name as cat_name FROM items i JOIN users u ON i.user_id=u.id LEFT JOIN categories c ON i.category_id=c.id WHERE i.status!='removed' ORDER BY i.created_at DESC LIMIT 5`).all(),
    recent_users: db.prepare('SELECT id, name, email, created_at, last_login FROM users WHERE role=? ORDER BY created_at DESC LIMIT 5').all('user'),
  };
  res.json(stats);
});

router.get('/admin/users', adminMiddleware, (req, res) => {
  const users = db.prepare(`
    SELECT u.*, 
           COUNT(DISTINCT i.id) as items_count,
           COUNT(DISTINCT c.id) as claims_count
    FROM users u
    LEFT JOIN items i ON u.id = i.user_id AND i.status != 'removed'
    LEFT JOIN claims c ON u.id = c.claimant_id
    WHERE u.role = 'user'
    GROUP BY u.id ORDER BY u.created_at DESC
  `).all();
  res.json(users.map(({ password, reset_token, ...u }) => u));
});

router.put('/admin/users/:id/block', adminMiddleware, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  db.prepare('UPDATE users SET is_blocked = ? WHERE id = ?').run(user.is_blocked ? 0 : 1, user.id);
  res.json({ blocked: !user.is_blocked });
});

router.delete('/admin/users/:id', adminMiddleware, (req, res) => {
  db.prepare('DELETE FROM users WHERE id = ? AND role != ?').run(req.params.id, 'admin');
  res.json({ message: 'User deleted' });
});

router.get('/admin/items', adminMiddleware, (req, res) => {
  const items = db.prepare(`
    SELECT i.*, u.name as user_name, c.name as category_name, COUNT(cl.id) as claims_count
    FROM items i
    JOIN users u ON i.user_id = u.id
    LEFT JOIN categories c ON i.category_id = c.id
    LEFT JOIN claims cl ON i.id = cl.item_id
    GROUP BY i.id ORDER BY i.created_at DESC
  `).all();
  res.json(items);
});

router.get('/admin/reports', adminMiddleware, (req, res) => {
  const reports = db.prepare(`
    SELECT r.*, i.title as item_title, u.name as reporter_name, o.name as owner_name
    FROM reported_items r
    JOIN items i ON r.item_id = i.id
    JOIN users u ON r.reporter_id = u.id
    JOIN users o ON i.user_id = o.id
    ORDER BY r.created_at DESC
  `).all();
  res.json(reports);
});

router.put('/admin/reports/:id', adminMiddleware, (req, res) => {
  const { status, action } = req.body;
  const report = db.prepare('SELECT * FROM reported_items WHERE id = ?').get(req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found' });
  db.prepare('UPDATE reported_items SET status = ? WHERE id = ?').run(status, report.id);
  if (action === 'remove') db.prepare("UPDATE items SET status='removed', is_flagged=1 WHERE id=?").run(report.item_id);
  res.json({ ok: true });
});

router.get('/admin/logs', adminMiddleware, (req, res) => {
  const logs = db.prepare(`
    SELECT l.*, u.name as user_name FROM activity_logs l
    LEFT JOIN users u ON l.user_id = u.id
    ORDER BY l.created_at DESC LIMIT 200
  `).all();
  res.json(logs);
});

router.post('/admin/announce', adminMiddleware, (req, res) => {
  const { title, message } = req.body;
  const users = db.prepare("SELECT id FROM users WHERE role = 'user'").all();
  const stmt = db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,'announcement')`);
  users.forEach(u => stmt.run(u.id, title, message));
  res.json({ sent: users.length });
});

module.exports = router;
