const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../database/db');
const { authMiddleware, JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

// Register
router.post('/register', (req, res) => {
  const { name, email, password, phone } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Name, email, and password required' });

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(409).json({ error: 'Email already registered' });

  const hashed = bcrypt.hashSync(password, 10);
  const result = db.prepare('INSERT INTO users (name, email, password, phone) VALUES (?, ?, ?, ?)').run(name, email, hashed, phone || null);
  
  db.prepare(`INSERT INTO activity_logs (user_id, action, details) VALUES (?, ?, ?)`).run(result.lastInsertRowid, 'register', 'User registered');
  db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)`).run(result.lastInsertRowid, 'Welcome!', 'Welcome to Lost & Found. Start by reporting a lost or found item.', 'info');

  const token = jwt.sign({ id: result.lastInsertRowid }, JWT_SECRET, { expiresIn: '7d' });
  const user = db.prepare('SELECT id, name, email, phone, role FROM users WHERE id = ?').get(result.lastInsertRowid);
  res.json({ token, user });
});

// Login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: 'Invalid credentials' });
  if (user.is_blocked) return res.status(403).json({ error: 'Account is blocked' });

  db.prepare('UPDATE users SET last_login = strftime(\'%s\',\'now\') WHERE id = ?').run(user.id);
  db.prepare(`INSERT INTO activity_logs (user_id, action) VALUES (?, ?)`).run(user.id, 'login');

  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
  const { password: _, reset_token: __, ...safeUser } = user;
  res.json({ token, user: safeUser });
});

// Get current user
router.get('/me', authMiddleware, (req, res) => {
  const { password, reset_token, ...safe } = req.user;
  res.json(safe);
});

// Update profile
router.put('/profile', authMiddleware, (req, res) => {
  const { name, phone } = req.body;
  db.prepare('UPDATE users SET name = ?, phone = ? WHERE id = ?').run(name, phone, req.user.id);
  const user = db.prepare('SELECT id, name, email, phone, role FROM users WHERE id = ?').get(req.user.id);
  res.json(user);
});

// Change password
router.put('/change-password', authMiddleware, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!bcrypt.compareSync(currentPassword, req.user.password))
    return res.status(400).json({ error: 'Current password is incorrect' });
  const hashed = bcrypt.hashSync(newPassword, 10);
  db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashed, req.user.id);
  res.json({ message: 'Password updated successfully' });
});

// Forgot password
router.post('/forgot-password', (req, res) => {
  const { email } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.json({ message: 'If email exists, reset link sent' });

  const token = uuidv4();
  const expiry = Math.floor(Date.now() / 1000) + 3600;
  db.prepare('UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?').run(token, expiry, user.id);
  
  // In production, send email. For demo, return token.
  res.json({ message: 'Reset token generated', token, note: 'In production, this would be emailed' });
});

// Reset password
router.post('/reset-password', (req, res) => {
  const { token, newPassword } = req.body;
  const now = Math.floor(Date.now() / 1000);
  const user = db.prepare('SELECT * FROM users WHERE reset_token = ? AND reset_token_expiry > ?').get(token, now);
  if (!user) return res.status(400).json({ error: 'Invalid or expired reset token' });

  const hashed = bcrypt.hashSync(newPassword, 10);
  db.prepare('UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?').run(hashed, user.id);
  res.json({ message: 'Password reset successfully' });
});

module.exports = router;
