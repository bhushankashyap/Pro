const express = require('express');
const multer = require('multer');
const path = require('path');
const { db } = require('../database/db');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

const router = express.Router();
const storage = multer.diskStorage({ destination: path.join(__dirname, '../uploads'), filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`) });
const upload = multer({ storage });

// Submit claim
router.post('/', authMiddleware, upload.single('proof'), (req, res) => {
  const { item_id, description } = req.body;
  if (!item_id || !description) return res.status(400).json({ error: 'Item ID and description required' });

  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(item_id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  if (item.user_id === req.user.id) return res.status(400).json({ error: 'Cannot claim your own item' });
  
  const existing = db.prepare('SELECT id FROM claims WHERE item_id = ? AND claimant_id = ?').get(item_id, req.user.id);
  if (existing) return res.status(409).json({ error: 'You already have a claim on this item' });

  const result = db.prepare('INSERT INTO claims (item_id, claimant_id, description, proof_image) VALUES (?,?,?,?)').run(item_id, req.user.id, description, req.file?.filename || null);
  
  // Notify item owner
  db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)`).run(item.user_id, 'New Claim Received', `Someone claimed your ${item.type} item: "${item.title}"`, 'claim');
  
  res.status(201).json(db.prepare('SELECT * FROM claims WHERE id = ?').get(result.lastInsertRowid));
});

// Get user's claims
router.get('/my', authMiddleware, (req, res) => {
  const claims = db.prepare(`
    SELECT cl.*, i.title as item_title, i.type as item_type, i.uuid as item_uuid,
           GROUP_CONCAT(ii.filename) as item_images
    FROM claims cl
    JOIN items i ON cl.item_id = i.id
    LEFT JOIN item_images ii ON i.id = ii.item_id
    WHERE cl.claimant_id = ?
    GROUP BY cl.id ORDER BY cl.created_at DESC
  `).all(req.user.id);
  res.json(claims.map(c => ({ ...c, item_images: c.item_images ? c.item_images.split(',') : [] })));
});

// Get claims on user's items
router.get('/received', authMiddleware, (req, res) => {
  const claims = db.prepare(`
    SELECT cl.*, i.title as item_title, i.type as item_type, i.uuid as item_uuid,
           u.name as claimant_name, u.email as claimant_email, u.phone as claimant_phone
    FROM claims cl
    JOIN items i ON cl.item_id = i.id
    JOIN users u ON cl.claimant_id = u.id
    WHERE i.user_id = ?
    ORDER BY cl.created_at DESC
  `).all(req.user.id);
  res.json(claims);
});

// Update claim status (item owner or admin)
router.put('/:id', authMiddleware, (req, res) => {
  const { status, admin_note } = req.body;
  const claim = db.prepare(`SELECT cl.*, i.user_id as item_owner FROM claims cl JOIN items i ON cl.item_id = i.id WHERE cl.id = ?`).get(req.params.id);
  if (!claim) return res.status(404).json({ error: 'Claim not found' });
  if (claim.item_owner !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  db.prepare(`UPDATE claims SET status=?, admin_note=?, updated_at=strftime('%s','now') WHERE id=?`).run(status, admin_note || null, claim.id);

  // Notify claimant
  const msg = status === 'approved' ? 'Your claim has been approved! Contact the owner.' : status === 'rejected' ? 'Your claim was rejected.' : 'Your claim status updated.';
  db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)`).run(claim.claimant_id, 'Claim Update', msg, status === 'approved' ? 'success' : 'info');

  if (status === 'approved') {
    db.prepare(`UPDATE items SET status='resolved' WHERE id=?`).run(claim.item_id);
  }

  res.json(db.prepare('SELECT * FROM claims WHERE id = ?').get(req.params.id));
});

// Admin: get all claims
router.get('/admin/all', adminMiddleware, (req, res) => {
  const claims = db.prepare(`
    SELECT cl.*, i.title as item_title, i.type as item_type, u.name as claimant_name, u.email as claimant_email, o.name as owner_name
    FROM claims cl
    JOIN items i ON cl.item_id = i.id
    JOIN users u ON cl.claimant_id = u.id
    JOIN users o ON i.user_id = o.id
    ORDER BY cl.created_at DESC
  `).all();
  res.json(claims);
});

module.exports = router;
