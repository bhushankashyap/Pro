const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const QRCode = require('qrcode');
const { db } = require('../database/db');
const { authMiddleware, optionalAuth } = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: path.join(__dirname, '../uploads'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

function getItems(filters = {}, userId = null) {
  let query = `
    SELECT i.*, u.name as user_name, u.email as user_email, u.phone as user_phone,
           c.name as category_name, c.icon as category_icon,
           GROUP_CONCAT(ii.filename) as images
    FROM items i
    JOIN users u ON i.user_id = u.id
    LEFT JOIN categories c ON i.category_id = c.id
    LEFT JOIN item_images ii ON i.id = ii.item_id
    WHERE i.status != 'removed'
  `;
  const params = [];

  if (filters.type) { query += ' AND i.type = ?'; params.push(filters.type); }
  if (filters.category_id) { query += ' AND i.category_id = ?'; params.push(filters.category_id); }
  if (filters.search) { query += ' AND (i.title LIKE ? OR i.description LIKE ? OR i.location LIKE ?)'; const s = `%${filters.search}%`; params.push(s, s, s); }
  if (filters.location) { query += ' AND i.location LIKE ?'; params.push(`%${filters.location}%`); }
  if (filters.date_from) { query += ' AND i.date_occurred >= ?'; params.push(filters.date_from); }
  if (filters.date_to) { query += ' AND i.date_occurred <= ?'; params.push(filters.date_to); }
  if (filters.user_id) { query += ' AND i.user_id = ?'; params.push(filters.user_id); }
  if (filters.status) { query += ' AND i.status = ?'; params.push(filters.status); }

  query += ' GROUP BY i.id ORDER BY i.created_at DESC';

  const limit = parseInt(filters.limit) || 20;
  const offset = parseInt(filters.offset) || 0;
  query += ` LIMIT ? OFFSET ?`;
  params.push(limit, offset);

  const items = db.prepare(query).all(...params);
  return items.map(item => ({
    ...item,
    images: item.images ? item.images.split(',') : [],
    is_bookmarked: userId ? !!db.prepare('SELECT id FROM bookmarks WHERE user_id = ? AND item_id = ?').get(userId, item.id) : false
  }));
}

// Get all items
router.get('/', optionalAuth, (req, res) => {
  const items = getItems(req.query, req.user?.id);
  res.json(items);
});

// Get single item
router.get('/:id', optionalAuth, (req, res) => {
  const item = db.prepare(`
    SELECT i.*, u.name as user_name, u.email as user_email, u.phone as user_phone,
           c.name as category_name, c.icon as category_icon,
           GROUP_CONCAT(ii.filename) as images
    FROM items i
    JOIN users u ON i.user_id = u.id
    LEFT JOIN categories c ON i.category_id = c.id
    LEFT JOIN item_images ii ON i.id = ii.item_id
    WHERE i.uuid = ? OR i.id = ?
    GROUP BY i.id
  `).get(req.params.id, req.params.id);

  if (!item) return res.status(404).json({ error: 'Item not found' });
  db.prepare('UPDATE items SET views = views + 1 WHERE id = ?').run(item.id);

  const claims = db.prepare('SELECT COUNT(*) as count FROM claims WHERE item_id = ?').get(item.id);
  res.json({
    ...item,
    images: item.images ? item.images.split(',') : [],
    claims_count: claims.count,
    is_bookmarked: req.user ? !!db.prepare('SELECT id FROM bookmarks WHERE user_id = ? AND item_id = ?').get(req.user.id, item.id) : false
  });
});

// Create item
router.post('/', authMiddleware, upload.array('images', 5), (req, res) => {
  const { title, description, category_id, type, location, date_occurred, contact_preference, safe_custody } = req.body;
  if (!title || !description || !type || !location || !date_occurred)
    return res.status(400).json({ error: 'Missing required fields' });

  const uuid = uuidv4();
  const result = db.prepare(`
    INSERT INTO items (uuid, user_id, title, description, category_id, type, location, date_occurred, contact_preference, safe_custody)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(uuid, req.user.id, title, description, category_id || null, type, location, date_occurred, contact_preference || 'email', safe_custody ? 1 : 0);

  if (req.files?.length) {
    const insertImg = db.prepare('INSERT INTO item_images (item_id, filename) VALUES (?, ?)');
    req.files.forEach(f => insertImg.run(result.lastInsertRowid, f.filename));
  }

  db.prepare(`INSERT INTO activity_logs (user_id, action, details) VALUES (?, ?, ?)`).run(req.user.id, 'post_item', `Posted ${type} item: ${title}`);

  // Notify users with matching items
  const matchType = type === 'lost' ? 'found' : 'lost';
  const matches = db.prepare(`SELECT DISTINCT user_id FROM items WHERE type = ? AND status = 'active' AND user_id != ? AND (title LIKE ? OR description LIKE ?)`).all(matchType, req.user.id, `%${title.split(' ')[0]}%`, `%${title.split(' ')[0]}%`);
  const notifyStmt = db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)`);
  matches.slice(0, 5).forEach(m => notifyStmt.run(m.user_id, 'Possible Match Found!', `A new ${type} item "${title}" may match your post.`, 'match'));

  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ ...item, uuid });
});

// Update item
router.put('/:id', authMiddleware, (req, res) => {
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  if (item.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  const { title, description, category_id, location, date_occurred, contact_preference, status } = req.body;
  db.prepare(`UPDATE items SET title=?, description=?, category_id=?, location=?, date_occurred=?, contact_preference=?, status=?, updated_at=strftime('%s','now') WHERE id=?`)
    .run(title || item.title, description || item.description, category_id || item.category_id, location || item.location, date_occurred || item.date_occurred, contact_preference || item.contact_preference, status || item.status, item.id);

  res.json(db.prepare('SELECT * FROM items WHERE id = ?').get(item.id));
});

// Delete item
router.delete('/:id', authMiddleware, (req, res) => {
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  if (item.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  db.prepare("UPDATE items SET status = 'removed' WHERE id = ?").run(item.id);
  res.json({ message: 'Item removed' });
});

// Get QR code for item
router.get('/:id/qr', async (req, res) => {
  const item = db.prepare('SELECT uuid FROM items WHERE id = ? OR uuid = ?').get(req.params.id, req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });

  const url = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/items/${item.uuid}`;
  const qr = await QRCode.toDataURL(url);
  res.json({ qr, url });
});

// Report item
router.post('/:id/report', authMiddleware, (req, res) => {
  const { reason } = req.body;
  const item = db.prepare('SELECT id FROM items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });

  db.prepare('INSERT OR IGNORE INTO reported_items (item_id, reporter_id, reason) VALUES (?,?,?)').run(item.id, req.user.id, reason);
  res.json({ message: 'Item reported' });
});

// Bookmark
router.post('/:id/bookmark', authMiddleware, (req, res) => {
  const item = db.prepare('SELECT id FROM items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });

  const existing = db.prepare('SELECT id FROM bookmarks WHERE user_id = ? AND item_id = ?').get(req.user.id, item.id);
  if (existing) {
    db.prepare('DELETE FROM bookmarks WHERE user_id = ? AND item_id = ?').run(req.user.id, item.id);
    return res.json({ bookmarked: false });
  }
  db.prepare('INSERT INTO bookmarks (user_id, item_id) VALUES (?,?)').run(req.user.id, item.id);
  res.json({ bookmarked: true });
});

// Get bookmarks
router.get('/user/bookmarks', authMiddleware, (req, res) => {
  const items = db.prepare(`
    SELECT i.*, c.name as category_name, c.icon as category_icon, GROUP_CONCAT(ii.filename) as images
    FROM bookmarks b
    JOIN items i ON b.item_id = i.id
    LEFT JOIN categories c ON i.category_id = c.id
    LEFT JOIN item_images ii ON i.id = ii.item_id
    WHERE b.user_id = ? AND i.status != 'removed'
    GROUP BY i.id ORDER BY b.created_at DESC
  `).all(req.user.id);
  res.json(items.map(i => ({ ...i, images: i.images ? i.images.split(',') : [], is_bookmarked: true })));
});

module.exports = router;
