import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Items from './pages/Items';
import ItemDetail from './pages/ItemDetail';
import ItemForm from './pages/ItemForm';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import Admin from './pages/Admin';
import ForgotPassword from './pages/ForgotPassword';

function ProtectedRoute({ children, adminOnly = false }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex items-center justify-center min-h-screen"><div className="text-4xl animate-spin">🔍</div></div>;
  if (!user) return <Navigate to="/login" replace/>;
  if (adminOnly && user.role !== 'admin') return <Navigate to="/dashboard" replace/>;
  return children;
}

function AppRoutes() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar/>
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/login" element={<Login/>}/>
          <Route path="/register" element={<Register/>}/>
          <Route path="/forgot-password" element={<ForgotPassword/>}/>
          <Route path="/items" element={<Items/>}/>
          <Route path="/items/:id" element={<ItemDetail/>}/>
          <Route path="/items/new" element={<ProtectedRoute><ItemForm/></ProtectedRoute>}/>
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard/></ProtectedRoute>}/>
          <Route path="/profile" element={<ProtectedRoute><Profile/></ProtectedRoute>}/>
          <Route path="/admin" element={<ProtectedRoute adminOnly><Admin/></ProtectedRoute>}/>
          <Route path="*" element={<div className="text-center py-20"><div className="text-6xl mb-4">🔍</div><h1 className="font-display font-bold text-3xl mb-2">404 – Page Not Found</h1><a href="/" className="text-primary-600 hover:underline">Go Home</a></div>}/>
        </Routes>
      </main>
      <footer className="bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 py-6 text-center text-sm text-gray-400">
        <p>🔍 Lost & Found Platform · Built with React + Node.js · <span className="text-primary-500">Reuniting People with Their Belongings</span></p>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <AppRoutes/>
          <Toaster position="top-right" toastOptions={{ className: 'font-sans text-sm', duration: 3500, style: { borderRadius: '12px' } }}/>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
