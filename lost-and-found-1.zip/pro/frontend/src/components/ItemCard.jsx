import { Link } from 'react-router-dom';
import { MapPin, Calendar, Eye, Bookmark, BookmarkCheck } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';
import toast from 'react-hot-toast';

export default function ItemCard({ item, onBookmarkToggle }) {
  const { user } = useAuth();
  const [bookmarked, setBookmarked] = useState(item.is_bookmarked);
  const img = item.images?.[0];

  const toggleBookmark = async (e) => {
    e.preventDefault();
    if (!user) return toast.error('Login to bookmark items');
    try {
      const { data } = await api.post(`/items/${item.id}/bookmark`);
      setBookmarked(data.bookmarked);
      onBookmarkToggle?.(item.id, data.bookmarked);
    } catch { toast.error('Failed to bookmark'); }
  };

  return (
    <Link to={`/items/${item.uuid || item.id}`} className="item-card block">
      <div className="relative aspect-[4/3] bg-gray-100 dark:bg-gray-800 overflow-hidden">
        {img ? (
          <img src={`/uploads/${img}`} alt={item.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-5xl">
            {item.category_icon || '📦'}
          </div>
        )}
        <div className="absolute top-2 left-2 flex gap-1.5">
          <span className={item.type === 'lost' ? 'badge-lost' : 'badge-found'}>
            {item.type === 'lost' ? '🔴 Lost' : '🟢 Found'}
          </span>
          {item.status === 'resolved' && <span className="badge-resolved">✅ Resolved</span>}
        </div>
        {user && (
          <button onClick={toggleBookmark} className="absolute top-2 right-2 p-1.5 rounded-lg bg-white/80 dark:bg-gray-900/80 hover:bg-white dark:hover:bg-gray-900 transition-colors">
            {bookmarked ? <BookmarkCheck size={16} className="text-primary-600" /> : <Bookmark size={16} className="text-gray-500" />}
          </button>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 px-2 py-0.5 rounded-full">
            {item.category_icon} {item.category_name || 'Other'}
          </span>
        </div>
        <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate mt-1">{item.title}</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">{item.description}</p>
        <div className="mt-3 flex items-center justify-between text-xs text-gray-400">
          <span className="flex items-center gap-1"><MapPin size={11}/>{item.location}</span>
          <span className="flex items-center gap-1"><Eye size={11}/>{item.views || 0}</span>
        </div>
        <div className="mt-1.5 flex items-center gap-1 text-xs text-gray-400">
          <Calendar size={11}/>
          {(() => { try { return formatDistanceToNow(new Date(item.created_at * 1000), { addSuffix: true }); } catch { return 'Recently'; } })()}
        </div>
      </div>
    </Link>
  );
}
