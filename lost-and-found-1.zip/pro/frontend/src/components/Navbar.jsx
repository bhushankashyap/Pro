import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { Bell, Search, Sun, Moon, Menu, X, Plus, LogOut, User, LayoutDashboard, Shield } from 'lucide-react';
import api from '../utils/api';

export default function Navbar() {
  const { user, logout, isAdmin } = useAuth();
  const { dark, toggle } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifs, setNotifs] = useState([]);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (user) {
      api.get('/notifications').then(r => {
        setNotifs(r.data.slice(0, 8));
        setUnread(r.data.filter(n => !n.is_read).length);
      }).catch(() => {});
    }
  }, [user, location]);

  const handleLogout = () => { logout(); navigate('/'); setMenuOpen(false); };

  const markAllRead = async () => {
    await api.put('/notifications/read-all');
    setNotifs(n => n.map(x => ({ ...x, is_read: 1 })));
    setUnread(0);
  };

  const notifIcon = { info: '💡', match: '🎯', claim: '📋', success: '✅', message: '💬', announcement: '📢' };

  return (
    <nav className="sticky top-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 font-display font-bold text-xl">
            <span className="text-2xl">🔍</span>
            <span className="bg-gradient-to-r from-primary-600 to-accent-600 bg-clip-text text-transparent">Lost & Found</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            <Link to="/items" className="px-4 py-2 rounded-xl text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">Browse</Link>
            {user && <Link to="/dashboard" className="px-4 py-2 rounded-xl text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">Dashboard</Link>}
            {isAdmin && <Link to="/admin" className="px-4 py-2 rounded-xl text-sm font-medium text-accent-600 dark:text-accent-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors flex items-center gap-1"><Shield size={14}/>Admin</Link>}
          </div>

          <div className="flex items-center gap-2">
            <button onClick={toggle} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-gray-500 dark:text-gray-400">
              {dark ? <Sun size={18}/> : <Moon size={18}/>}
            </button>

            {user ? (
              <>
                <Link to="/items/new" className="hidden md:flex items-center gap-1.5 btn-primary text-sm py-2">
                  <Plus size={16}/> Report Item
                </Link>

                {/* Notifications */}
                <div className="relative">
                  <button onClick={() => { setNotifOpen(!notifOpen); setMenuOpen(false); }} className="relative p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-gray-500 dark:text-gray-400">
                    <Bell size={18}/>
                    {unread > 0 && <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 rounded-full text-white text-[9px] font-bold flex items-center justify-center">{unread > 9 ? '9+' : unread}</span>}
                  </button>
                  {notifOpen && (
                    <div className="absolute right-0 mt-2 w-80 card shadow-lg overflow-hidden">
                      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                        <h3 className="font-semibold text-sm">Notifications</h3>
                        <button onClick={markAllRead} className="text-xs text-primary-600 hover:underline">Mark all read</button>
                      </div>
                      <div className="max-h-72 overflow-y-auto divide-y divide-gray-50 dark:divide-gray-800">
                        {notifs.length === 0 ? <p className="p-4 text-sm text-gray-400 text-center">No notifications</p> :
                          notifs.map(n => (
                            <div key={n.id} className={`px-4 py-3 flex gap-3 ${!n.is_read ? 'bg-primary-50 dark:bg-primary-900/10' : ''}`}>
                              <span className="text-lg flex-shrink-0">{notifIcon[n.type] || '🔔'}</span>
                              <div>
                                <p className="text-sm font-medium">{n.title}</p>
                                <p className="text-xs text-gray-500 mt-0.5">{n.message}</p>
                              </div>
                            </div>
                          ))
                        }
                      </div>
                      <Link to="/notifications" onClick={() => setNotifOpen(false)} className="block text-center text-xs text-primary-600 py-2.5 hover:bg-gray-50 dark:hover:bg-gray-800 border-t border-gray-100 dark:border-gray-800">View all</Link>
                    </div>
                  )}
                </div>

                {/* User Menu */}
                <div className="relative">
                  <button onClick={() => { setMenuOpen(!menuOpen); setNotifOpen(false); }} className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white text-xs font-bold">
                      {user.name?.[0]?.toUpperCase()}
                    </div>
                    <span className="hidden md:block text-sm font-medium max-w-24 truncate">{user.name}</span>
                  </button>
                  {menuOpen && (
                    <div className="absolute right-0 mt-2 w-48 card shadow-lg py-1">
                      <Link to="/profile" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-gray-800"><User size={15}/>Profile</Link>
                      <Link to="/dashboard" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-gray-800"><LayoutDashboard size={15}/>Dashboard</Link>
                      <Link to="/items/new" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-gray-800"><Plus size={15}/>Report Item</Link>
                      {isAdmin && <Link to="/admin" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm text-accent-600 hover:bg-gray-50 dark:hover:bg-gray-800"><Shield size={15}/>Admin Panel</Link>}
                      <hr className="my-1 border-gray-100 dark:border-gray-800"/>
                      <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2.5 text-sm text-red-500 hover:bg-gray-50 dark:hover:bg-gray-800 w-full"><LogOut size={15}/>Logout</button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login" className="btn-secondary text-sm py-2 px-4">Login</Link>
                <Link to="/register" className="btn-primary text-sm py-2 px-4 hidden sm:inline-flex">Sign Up</Link>
              </div>
            )}

            {/* Mobile menu button */}
            <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500">
              {menuOpen ? <X size={20}/> : <Menu size={20}/>}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden py-3 border-t border-gray-100 dark:border-gray-800 space-y-1">
            <Link to="/items" onClick={() => setMenuOpen(false)} className="block px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-gray-100 dark:hover:bg-gray-800">Browse Items</Link>
            {user && <>
              <Link to="/dashboard" onClick={() => setMenuOpen(false)} className="block px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-gray-100 dark:hover:bg-gray-800">Dashboard</Link>
              <Link to="/items/new" onClick={() => setMenuOpen(false)} className="block px-4 py-2.5 rounded-xl text-sm font-medium text-primary-600 hover:bg-gray-100 dark:hover:bg-gray-800">+ Report Item</Link>
              {isAdmin && <Link to="/admin" onClick={() => setMenuOpen(false)} className="block px-4 py-2.5 rounded-xl text-sm font-medium text-accent-600 hover:bg-gray-100 dark:hover:bg-gray-800">Admin Panel</Link>}
              <button onClick={handleLogout} className="block w-full text-left px-4 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:bg-gray-100 dark:hover:bg-gray-800">Logout</button>
            </>}
            {!user && <>
              <Link to="/login" onClick={() => setMenuOpen(false)} className="block px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-gray-100 dark:hover:bg-gray-800">Login</Link>
              <Link to="/register" onClick={() => setMenuOpen(false)} className="block px-4 py-2.5 rounded-xl text-sm font-medium text-primary-600 hover:bg-gray-100 dark:hover:bg-gray-800">Sign Up</Link>
            </>}
          </div>
        )}
      </div>
    </nav>
  );
}
