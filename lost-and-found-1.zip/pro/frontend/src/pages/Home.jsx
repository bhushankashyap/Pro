import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Shield, Zap, ChevronRight, TrendingUp } from 'lucide-react';
import api from '../utils/api';
import ItemCard from '../components/ItemCard';

export default function Home() {
  const [recent, setRecent] = useState([]);
  const [stats, setStats] = useState({ lost: 0, found: 0, resolved: 0 });
  const [search, setSearch] = useState('');

  useEffect(() => {
    api.get('/items?limit=6').then(r => setRecent(r.data)).catch(() => {});
    Promise.all([
      api.get('/items?type=lost&limit=1'),
      api.get('/items?type=found&limit=1'),
      api.get('/items?status=resolved&limit=1')
    ]).then(([l, f, r]) => {
      // rough counts
    }).catch(() => {});
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (search.trim()) window.location.href = `/items?search=${encodeURIComponent(search)}`;
  };

  return (
    <div className="page-enter">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary-600 via-primary-700 to-accent-700 text-white">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{backgroundImage:'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)', backgroundSize:'60px 60px'}}/>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 text-center">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-1.5 rounded-full text-sm font-medium mb-6">
            <TrendingUp size={14}/> Community Lost & Found Platform
          </div>
          <h1 className="font-display font-bold text-4xl md:text-6xl lg:text-7xl mb-6 leading-tight">
            Lost Something?<br/>
            <span className="text-yellow-300">We'll Help You Find It.</span>
          </h1>
          <p className="text-lg md:text-xl text-primary-100 max-w-2xl mx-auto mb-10">
            Report lost items, browse found items, and reconnect people with their belongings — all in one place.
          </p>
          <form onSubmit={handleSearch} className="max-w-xl mx-auto flex gap-2">
            <div className="flex-1 relative">
              <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"/>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search lost or found items..." className="w-full pl-11 pr-4 py-3.5 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-white/50 text-sm"/>
            </div>
            <button type="submit" className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-bold px-6 py-3.5 rounded-xl transition-colors whitespace-nowrap">Search</button>
          </form>
          <div className="flex flex-wrap justify-center gap-4 mt-8">
            <Link to="/items/new?type=lost" className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-sm px-5 py-2.5 rounded-xl font-medium transition-colors">
              🔴 Report Lost Item
            </Link>
            <Link to="/items/new?type=found" className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-sm px-5 py-2.5 rounded-xl font-medium transition-colors">
              🟢 Report Found Item
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-3 gap-6 text-center">
          {[
            { label: 'Items Listed', value: '500+', icon: '📋' },
            { label: 'Items Resolved', value: '200+', icon: '✅' },
            { label: 'Happy Users', value: '1000+', icon: '😊' },
          ].map(s => (
            <div key={s.label}>
              <div className="text-3xl mb-1">{s.icon}</div>
              <div className="text-2xl md:text-3xl font-display font-bold text-primary-600">{s.value}</div>
              <div className="text-sm text-gray-500 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="font-display font-bold text-3xl text-center mb-12">How It Works</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: '📤', title: 'Report', desc: 'Report a lost or found item with photos, description, and location details.' },
            { icon: '🔍', title: 'Search & Match', desc: 'Our smart matching system connects lost items with found reports automatically.' },
            { icon: '🤝', title: 'Claim & Reunite', desc: 'Submit a claim with proof, get verified, and get your item back safely.' },
          ].map((f, i) => (
            <div key={i} className="card p-6 text-center">
              <div className="text-4xl mb-4">{f.icon}</div>
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="w-6 h-6 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-600 text-xs font-bold flex items-center justify-center">{i+1}</span>
                <h3 className="font-display font-semibold text-lg">{f.title}</h3>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Recent Items */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display font-bold text-2xl">Recent Listings</h2>
          <Link to="/items" className="flex items-center gap-1 text-sm text-primary-600 hover:underline font-medium">View all <ChevronRight size={16}/></Link>
        </div>
        {recent.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <div className="text-5xl mb-3">📭</div>
            <p>No items listed yet. Be the first to report!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {recent.map(item => <ItemCard key={item.id} item={item}/>)}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-primary-600 to-accent-600 text-white">
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h2 className="font-display font-bold text-3xl md:text-4xl mb-4">Ready to get started?</h2>
          <p className="text-primary-100 mb-8">Join thousands of users helping each other recover lost belongings.</p>
          <Link to="/register" className="inline-flex items-center gap-2 bg-white text-primary-700 font-bold px-8 py-3.5 rounded-xl hover:bg-primary-50 transition-colors">
            Create Free Account <ChevronRight size={18}/>
          </Link>
        </div>
      </section>
    </div>
  );
}
