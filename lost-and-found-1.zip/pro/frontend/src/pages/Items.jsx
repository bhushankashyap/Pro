import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter, X } from 'lucide-react';
import api from '../utils/api';
import ItemCard from '../components/ItemCard';

export default function Items() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    type: searchParams.get('type') || '',
    category_id: '',
    location: '',
    date_from: '',
    date_to: '',
  });
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    api.get('/categories').then(r => setCategories(r.data)).catch(() => {});
  }, []);

  useEffect(() => {
    fetchItems();
  }, [filters]);

  const fetchItems = async () => {
    setLoading(true);
    try {
      const params = Object.fromEntries(Object.entries(filters).filter(([,v]) => v));
      const { data } = await api.get('/items', { params });
      setItems(data);
    } catch { setItems([]); } finally { setLoading(false); }
  };

  const set = k => v => setFilters(f => ({...f, [k]: v}));
  const clear = () => setFilters({ search: '', type: '', category_id: '', location: '', date_from: '', date_to: '' });
  const activeFilters = Object.values(filters).filter(Boolean).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 page-enter">
      <div className="mb-6">
        <h1 className="font-display font-bold text-3xl mb-1">Browse Items</h1>
        <p className="text-gray-500 text-sm">{loading ? '...' : `${items.length} items found`}</p>
      </div>

      {/* Search + Filter Bar */}
      <div className="flex gap-3 mb-4">
        <div className="flex-1 relative">
          <Search size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"/>
          <input className="input pl-10" placeholder="Search items..." value={filters.search} onChange={e => set('search')(e.target.value)}/>
        </div>
        <button onClick={() => setShowFilters(s => !s)} className={`btn-secondary flex items-center gap-2 relative ${showFilters ? 'ring-2 ring-primary-500' : ''}`}>
          <Filter size={16}/> Filters
          {activeFilters > 0 && <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-primary-600 text-white text-xs rounded-full flex items-center justify-center font-bold">{activeFilters}</span>}
        </button>
        {activeFilters > 0 && <button onClick={clear} className="btn-secondary flex items-center gap-1 text-red-500"><X size={15}/>Clear</button>}
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <div className="card p-5 mb-5 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium mb-1.5 text-gray-600 dark:text-gray-400">Type</label>
            <select className="input text-sm" value={filters.type} onChange={e => set('type')(e.target.value)}>
              <option value="">All</option>
              <option value="lost">Lost</option>
              <option value="found">Found</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1.5 text-gray-600 dark:text-gray-400">Category</label>
            <select className="input text-sm" value={filters.category_id} onChange={e => set('category_id')(e.target.value)}>
              <option value="">All Categories</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1.5 text-gray-600 dark:text-gray-400">Location</label>
            <input className="input text-sm" placeholder="City, area..." value={filters.location} onChange={e => set('location')(e.target.value)}/>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1.5 text-gray-600 dark:text-gray-400">Date From</label>
            <input type="date" className="input text-sm" value={filters.date_from} onChange={e => set('date_from')(e.target.value)}/>
          </div>
        </div>
      )}

      {/* Type Tabs */}
      <div className="flex gap-2 mb-6">
        {[['', 'All Items'], ['lost', '🔴 Lost'], ['found', '🟢 Found']].map(([v, l]) => (
          <button key={v} onClick={() => set('type')(v)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${filters.type === v ? 'bg-primary-600 text-white' : 'bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
            {l}
          </button>
        ))}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="card overflow-hidden animate-pulse">
              <div className="aspect-[4/3] bg-gray-200 dark:bg-gray-800"/>
              <div className="p-4 space-y-2">
                <div className="h-3 bg-gray-200 dark:bg-gray-800 rounded w-1/3"/>
                <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-3/4"/>
                <div className="h-3 bg-gray-200 dark:bg-gray-800 rounded w-full"/>
              </div>
            </div>
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">🔎</div>
          <h3 className="font-display font-semibold text-xl mb-2">No items found</h3>
          <p className="text-gray-500">Try adjusting your filters or search terms</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {items.map(item => <ItemCard key={item.id} item={item}/>)}
        </div>
      )}
    </div>
  );
}
