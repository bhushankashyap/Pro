import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Upload, X, MapPin } from 'lucide-react';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function ItemForm() {
  const navigate = useNavigate();
  const [sp] = useSearchParams();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [previews, setPreviews] = useState([]);
  const [form, setForm] = useState({
    title: '', description: '', category_id: '', type: sp.get('type') || 'lost',
    location: '', date_occurred: new Date().toISOString().split('T')[0],
    contact_preference: 'email', safe_custody: false,
  });
  const [images, setImages] = useState([]);

  useEffect(() => { api.get('/categories').then(r => setCategories(r.data)).catch(() => {}); }, []);

  const set = k => e => setForm(f => ({...f, [k]: e.target.value}));

  const handleImages = e => {
    const files = Array.from(e.target.files).slice(0, 5);
    setImages(files);
    setPreviews(files.map(f => URL.createObjectURL(f)));
  };

  const removeImg = i => {
    setImages(imgs => imgs.filter((_, idx) => idx !== i));
    setPreviews(ps => ps.filter((_, idx) => idx !== i));
  };

  const submit = async e => {
    e.preventDefault();
    if (!form.title || !form.description || !form.location) return toast.error('Please fill in all required fields');
    setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      images.forEach(img => fd.append('images', img));
      const { data } = await api.post('/items', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success(`${form.type === 'lost' ? 'Lost' : 'Found'} item reported!`);
      navigate(`/items/${data.uuid}`);
    } catch (err) { toast.error(err.response?.data?.error || 'Failed to post item'); }
    finally { setLoading(false); }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8 page-enter">
      <div className="mb-6">
        <h1 className="font-display font-bold text-3xl">Report an Item</h1>
        <p className="text-gray-500 mt-1">Fill in the details to help others find your item</p>
      </div>

      <div className="card p-6 md:p-8">
        <form onSubmit={submit} className="space-y-6">
          {/* Type Toggle */}
          <div>
            <label className="block text-sm font-medium mb-2">I want to report a...</label>
            <div className="grid grid-cols-2 gap-3">
              {[['lost', '🔴', 'Lost Item', 'I lost something'], ['found', '🟢', 'Found Item', "I found someone's item"]].map(([v, icon, label, sub]) => (
                <button key={v} type="button" onClick={() => setForm(f => ({...f, type: v}))}
                  className={`p-4 rounded-xl border-2 text-left transition-all ${form.type === v ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'}`}>
                  <div className="text-2xl mb-1">{icon}</div>
                  <div className="font-semibold text-sm">{label}</div>
                  <div className="text-xs text-gray-500">{sub}</div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5">Title <span className="text-red-500">*</span></label>
            <input className="input" placeholder="e.g. Black wallet with ID cards" value={form.title} onChange={set('title')} required maxLength={100}/>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5">Category</label>
            <select className="input" value={form.category_id} onChange={set('category_id')}>
              <option value="">Select a category</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5">Description <span className="text-red-500">*</span></label>
            <textarea className="input min-h-[120px] resize-none" placeholder="Describe the item in detail — color, brand, distinguishing features..." value={form.description} onChange={set('description')} required maxLength={1000}/>
            <p className="text-xs text-gray-400 mt-1">{form.description.length}/1000</p>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5"><MapPin size={13} className="inline mr-1"/>Location <span className="text-red-500">*</span></label>
              <input className="input" placeholder="e.g. Central Park, New York" value={form.location} onChange={set('location')} required/>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Date {form.type === 'lost' ? 'Lost' : 'Found'} <span className="text-red-500">*</span></label>
              <input type="date" className="input" value={form.date_occurred} onChange={set('date_occurred')} max={new Date().toISOString().split('T')[0]} required/>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5">Contact Preference</label>
            <select className="input" value={form.contact_preference} onChange={set('contact_preference')}>
              <option value="email">Email</option>
              <option value="phone">Phone</option>
            </select>
          </div>

          {form.type === 'found' && (
            <div className="flex items-center gap-3 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl">
              <input type="checkbox" id="safe" checked={form.safe_custody} onChange={e => setForm(f => ({...f, safe_custody: e.target.checked}))} className="w-4 h-4 rounded accent-primary-600"/>
              <label htmlFor="safe" className="text-sm">
                <span className="font-medium">Mark as Safe Custody</span>
                <span className="block text-gray-500 text-xs">I have the item and will keep it safe until claimed</span>
              </label>
            </div>
          )}

          {/* Images */}
          <div>
            <label className="block text-sm font-medium mb-2">Photos (up to 5)</label>
            {previews.length > 0 && (
              <div className="flex gap-2 mb-3 flex-wrap">
                {previews.map((p, i) => (
                  <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden">
                    <img src={p} className="w-full h-full object-cover"/>
                    <button type="button" onClick={() => removeImg(i)} className="absolute top-0.5 right-0.5 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs">×</button>
                  </div>
                ))}
              </div>
            )}
            <label className="flex flex-col items-center gap-2 p-6 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-xl cursor-pointer hover:border-primary-400 transition-colors">
              <Upload size={24} className="text-gray-400"/>
              <span className="text-sm text-gray-500">Click to upload images</span>
              <span className="text-xs text-gray-400">PNG, JPG up to 5MB each</span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={handleImages}/>
            </label>
          </div>

          <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2 py-3">
            {loading ? 'Posting...' : `🚀 Post ${form.type === 'lost' ? 'Lost' : 'Found'} Item`}
          </button>
        </form>
      </div>
    </div>
  );
}
