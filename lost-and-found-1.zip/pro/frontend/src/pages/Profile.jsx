import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { User, Lock, Save } from 'lucide-react';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState({ name: user.name, phone: user.phone || '' });
  const [pw, setPw] = useState({ current: '', new: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const [pwLoading, setPwLoading] = useState(false);

  const saveProfile = async e => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.put('/auth/profile', form);
      updateUser(data);
      toast.success('Profile updated!');
    } catch (err) { toast.error(err.response?.data?.error || 'Update failed'); }
    finally { setLoading(false); }
  };

  const changePw = async e => {
    e.preventDefault();
    if (pw.new !== pw.confirm) return toast.error('Passwords do not match');
    if (pw.new.length < 6) return toast.error('Password must be at least 6 characters');
    setPwLoading(true);
    try {
      await api.put('/auth/change-password', { currentPassword: pw.current, newPassword: pw.new });
      toast.success('Password changed!');
      setPw({ current: '', new: '', confirm: '' });
    } catch (err) { toast.error(err.response?.data?.error || 'Failed to change password'); }
    finally { setPwLoading(false); }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8 page-enter">
      <h1 className="font-display font-bold text-3xl mb-6">My Profile</h1>

      {/* Avatar */}
      <div className="card p-6 mb-6 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white text-2xl font-bold">
          {user.name?.[0]?.toUpperCase()}
        </div>
        <div>
          <h2 className="font-semibold text-lg">{user.name}</h2>
          <p className="text-sm text-gray-500">{user.email}</p>
          <span className={`text-xs px-2 py-0.5 rounded-full font-medium mt-1 inline-block ${user.role === 'admin' ? 'bg-accent-100 text-accent-700 dark:bg-accent-900/30 dark:text-accent-400' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'}`}>
            {user.role}
          </span>
        </div>
      </div>

      {/* Profile Form */}
      <div className="card p-6 mb-6">
        <h2 className="font-semibold flex items-center gap-2 mb-4"><User size={18}/>Personal Info</h2>
        <form onSubmit={saveProfile} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5">Full Name</label>
            <input className="input" value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} required/>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Email</label>
            <input className="input bg-gray-50 dark:bg-gray-800/50" value={user.email} disabled/>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Phone</label>
            <input type="tel" className="input" value={form.phone} onChange={e => setForm(f => ({...f, phone: e.target.value}))} placeholder="+1 234 567 8900"/>
          </div>
          <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2">
            <Save size={16}/>{loading ? 'Saving...' : 'Save Changes'}
          </button>
        </form>
      </div>

      {/* Change Password */}
      <div className="card p-6">
        <h2 className="font-semibold flex items-center gap-2 mb-4"><Lock size={18}/>Change Password</h2>
        <form onSubmit={changePw} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5">Current Password</label>
            <input type="password" className="input" value={pw.current} onChange={e => setPw(p => ({...p, current: e.target.value}))} required/>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">New Password</label>
            <input type="password" className="input" value={pw.new} onChange={e => setPw(p => ({...p, new: e.target.value}))} required/>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Confirm New Password</label>
            <input type="password" className="input" value={pw.confirm} onChange={e => setPw(p => ({...p, confirm: e.target.value}))} required/>
          </div>
          <button type="submit" disabled={pwLoading} className="btn-primary flex items-center gap-2">
            <Lock size={16}/>{pwLoading ? 'Updating...' : 'Update Password'}
          </button>
        </form>
      </div>
    </div>
  );
}
