import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { MapPin, Calendar, Phone, Mail, Eye, Flag, BookmarkCheck, Bookmark, QrCode, Share2, ChevronLeft, Trash2, Edit } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function ItemDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [item, setItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [imgIdx, setImgIdx] = useState(0);
  const [claimModal, setClaimModal] = useState(false);
  const [claim, setClaim] = useState({ description: '', proof: null });
  const [claimLoading, setClaimLoading] = useState(false);
  const [qr, setQr] = useState(null);
  const [bookmarked, setBookmarked] = useState(false);

  useEffect(() => {
    api.get(`/items/${id}`).then(r => { setItem(r.data); setBookmarked(r.data.is_bookmarked); }).catch(() => navigate('/items')).finally(() => setLoading(false));
  }, [id]);

  const submitClaim = async e => {
    e.preventDefault();
    setClaimLoading(true);
    try {
      const fd = new FormData();
      fd.append('item_id', item.id);
      fd.append('description', claim.description);
      if (claim.proof) fd.append('proof', claim.proof);
      await api.post('/claims', fd);
      toast.success('Claim submitted successfully!');
      setClaimModal(false);
    } catch (err) { toast.error(err.response?.data?.error || 'Failed to submit claim'); }
    finally { setClaimLoading(false); }
  };

  const loadQR = async () => {
    if (qr) return setQr(null);
    const { data } = await api.get(`/items/${item.id}/qr`);
    setQr(data.qr);
  };

  const toggleBookmark = async () => {
    if (!user) return toast.error('Login to bookmark');
    const { data } = await api.post(`/items/${item.id}/bookmark`);
    setBookmarked(data.bookmarked);
    toast.success(data.bookmarked ? 'Bookmarked!' : 'Removed from bookmarks');
  };

  const deleteItem = async () => {
    if (!confirm('Delete this item?')) return;
    await api.delete(`/items/${item.id}`);
    toast.success('Item deleted');
    navigate('/dashboard');
  };

  const share = () => {
    if (navigator.share) navigator.share({ title: item.title, url: window.location.href });
    else { navigator.clipboard.writeText(window.location.href); toast.success('Link copied!'); }
  };

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-12 text-center"><div className="text-4xl animate-spin">🔍</div></div>;
  if (!item) return null;

  const isOwner = user?.id === item.user_id;
  const imgs = item.images || [];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 page-enter">
      <Link to="/items" className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 mb-6">
        <ChevronLeft size={16}/> Back to items
      </Link>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Images */}
        <div>
          <div className="aspect-[4/3] bg-gray-100 dark:bg-gray-800 rounded-2xl overflow-hidden">
            {imgs[imgIdx] ? (
              <img src={`/uploads/${imgs[imgIdx]}`} alt={item.title} className="w-full h-full object-cover"/>
            ) : (
              <div className="w-full h-full flex items-center justify-center text-7xl">{item.category_icon || '📦'}</div>
            )}
          </div>
          {imgs.length > 1 && (
            <div className="flex gap-2 mt-3">
              {imgs.map((img, i) => (
                <button key={i} onClick={() => setImgIdx(i)} className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-colors ${i === imgIdx ? 'border-primary-500' : 'border-transparent'}`}>
                  <img src={`/uploads/${img}`} className="w-full h-full object-cover"/>
                </button>
              ))}
            </div>
          )}
          {qr && <img src={qr} alt="QR Code" className="mt-4 w-40 h-40 mx-auto rounded-xl border border-gray-200 dark:border-gray-700"/>}
        </div>

        {/* Details */}
        <div>
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className={item.type === 'lost' ? 'badge-lost' : 'badge-found'}>
                  {item.type === 'lost' ? '🔴 Lost' : '🟢 Found'}
                </span>
                {item.status === 'resolved' && <span className="badge-resolved">✅ Resolved</span>}
                {item.safe_custody ? <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">🔒 Safe Custody</span> : null}
              </div>
              <h1 className="font-display font-bold text-2xl md:text-3xl">{item.title}</h1>
              <p className="text-sm text-gray-500 mt-1">{item.category_icon} {item.category_name}</p>
            </div>
            <div className="flex items-center gap-1.5">
              <button onClick={toggleBookmark} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                {bookmarked ? <BookmarkCheck size={20} className="text-primary-600"/> : <Bookmark size={20} className="text-gray-400"/>}
              </button>
              <button onClick={share} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-gray-400"><Share2 size={20}/></button>
              <button onClick={loadQR} className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-gray-400"><QrCode size={20}/></button>
            </div>
          </div>

          <div className="mt-5 space-y-3">
            <div className="flex items-center gap-2.5 text-sm text-gray-600 dark:text-gray-400">
              <MapPin size={16} className="text-primary-500 flex-shrink-0"/>
              <span>{item.location}</span>
            </div>
            <div className="flex items-center gap-2.5 text-sm text-gray-600 dark:text-gray-400">
              <Calendar size={16} className="text-primary-500 flex-shrink-0"/>
              <span>Date: {item.date_occurred} · Posted {(() => { try { return formatDistanceToNow(new Date(item.created_at * 1000), {addSuffix:true}); } catch { return 'recently'; }})()}</span>
            </div>
            <div className="flex items-center gap-2.5 text-sm text-gray-600 dark:text-gray-400">
              <Eye size={16} className="text-primary-500 flex-shrink-0"/>
              <span>{item.views} views · {item.claims_count} claims</span>
            </div>
          </div>

          <div className="mt-5 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
            <h3 className="font-semibold text-sm mb-2">Description</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{item.description}</p>
          </div>

          {/* Contact */}
          <div className="mt-5 p-4 card">
            <h3 className="font-semibold text-sm mb-3">Posted by</h3>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white font-bold">
                {item.user_name?.[0]?.toUpperCase()}
              </div>
              <div>
                <p className="font-medium text-sm">{item.user_name}</p>
                {item.contact_preference === 'email' || !item.contact_preference ?
                  <p className="text-xs text-gray-500 flex items-center gap-1"><Mail size={11}/>{item.user_email}</p> :
                  <p className="text-xs text-gray-500 flex items-center gap-1"><Phone size={11}/>{item.user_phone || item.user_email}</p>
                }
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="mt-5 flex flex-col gap-3">
            {!isOwner && user && item.status === 'active' && (
              <button onClick={() => setClaimModal(true)} className="btn-primary flex items-center justify-center gap-2">
                🤝 Claim This Item
              </button>
            )}
            {!user && (
              <Link to="/login" className="btn-primary flex items-center justify-center gap-2">
                Login to Claim
              </Link>
            )}
            {isOwner && (
              <div className="flex gap-3">
                <Link to={`/items/${item.id}/edit`} className="btn-secondary flex-1 flex items-center justify-center gap-2"><Edit size={16}/>Edit</Link>
                <button onClick={deleteItem} className="btn-danger flex items-center gap-2"><Trash2 size={16}/>Delete</button>
              </div>
            )}
            {!isOwner && user && (
              <button onClick={() => api.post(`/items/${item.id}/report`, {reason:'Suspicious or fake'}).then(() => toast.success('Reported'))} className="text-xs text-gray-400 hover:text-red-500 flex items-center gap-1 justify-center transition-colors">
                <Flag size={12}/>Report this item
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Claim Modal */}
      {claimModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="card w-full max-w-md p-6">
            <h2 className="font-display font-bold text-xl mb-4">Submit a Claim</h2>
            <form onSubmit={submitClaim} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Describe how this is yours</label>
                <textarea className="input min-h-[100px] resize-none" placeholder="Provide details that prove ownership..." value={claim.description} onChange={e => setClaim(c => ({...c, description: e.target.value}))} required/>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Proof image (optional)</label>
                <input type="file" accept="image/*" onChange={e => setClaim(c => ({...c, proof: e.target.files[0]}))} className="input text-sm file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0 file:bg-primary-50 file:text-primary-600 file:text-sm"/>
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setClaimModal(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={claimLoading} className="btn-primary flex-1">{claimLoading ? 'Submitting...' : 'Submit Claim'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
