import { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [token, setToken] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async e => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post('/auth/forgot-password', { email });
      setSent(true);
      setToken(data.token || '');
      toast.success('Reset link generated!');
    } catch { toast.error('Something went wrong'); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 page-enter">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🔐</div>
          <h1 className="font-display font-bold text-3xl">Reset Password</h1>
          <p className="text-gray-500 mt-2">Enter your email to get a reset token</p>
        </div>
        <div className="card p-8">
          {!sent ? (
            <form onSubmit={submit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium mb-1.5">Email Address</label>
                <input type="email" className="input" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required/>
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full">{loading ? 'Sending...' : 'Send Reset Link'}</button>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-xl text-green-700 dark:text-green-400 text-sm">
                ✅ In a real application, a reset email would be sent. For this demo, use the token below.
              </div>
              {token && (
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl">
                  <p className="text-xs text-gray-500 mb-1">Your reset token:</p>
                  <code className="text-xs break-all text-primary-600">{token}</code>
                </div>
              )}
              <Link to="/reset-password" state={{ token }} className="btn-primary block text-center">Continue to Reset</Link>
            </div>
          )}
        </div>
        <p className="text-center mt-6 text-sm"><Link to="/login" className="text-primary-600 hover:underline">← Back to login</Link></p>
      </div>
    </div>
  );
}
