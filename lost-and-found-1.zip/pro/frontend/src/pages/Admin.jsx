import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Users, Package, ClipboardList, CheckCircle, AlertTriangle, TrendingUp, Megaphone, Trash2, Ban, Flag } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function Admin() {
  const [tab, setTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [items, setItems] = useState([]);
  const [claims, setClaims] = useState([]);
  const [reports, setReports] = useState([]);
  const [logs, setLogs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [announce, setAnnounce] = useState({ title: '', message: '' });
  const [catForm, setCatForm] = useState({ name: '', icon: '📦' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/admin/dashboard').then(r => setStats(r.data)).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (tab === 'users' && !users.length) api.get('/admin/users').then(r => setUsers(r.data));
    if (tab === 'items' && !items.length) api.get('/admin/items').then(r => setItems(r.data));
    if (tab === 'claims' && !claims.length) api.get('/claims/admin/all').then(r => setClaims(r.data));
    if (tab === 'reports' && !reports.length) api.get('/admin/reports').then(r => setReports(r.data));
    if (tab === 'logs' && !logs.length) api.get('/admin/logs').then(r => setLogs(r.data));
    if (tab === 'categories' && !categories.length) api.get('/categories').then(r => setCategories(r.data));
  }, [tab]);

  const blockUser = async (id) => {
    const { data } = await api.put(`/admin/users/${id}/block`);
    setUsers(us => us.map(u => u.id === id ? {...u, is_blocked: data.blocked ? 1 : 0} : u));
    toast.success(data.blocked ? 'User blocked' : 'User unblocked');
  };

  const deleteUser = async (id) => {
    if (!confirm('Delete this user?')) return;
    await api.delete(`/admin/users/${id}`);
    setUsers(us => us.filter(u => u.id !== id));
    toast.success('User deleted');
  };

  const updateItemStatus = async (id, status) => {
    await api.put(`/items/${id}`, { status });
    setItems(is => is.map(i => i.id === id ? {...i, status} : i));
    toast.success('Item updated');
  };

  const handleReport = async (id, status, action) => {
    await api.put(`/admin/reports/${id}`, { status, action });
    setReports(rs => rs.map(r => r.id === id ? {...r, status} : r));
    toast.success('Report handled');
  };

  const sendAnnouncement = async () => {
    if (!announce.title || !announce.message) return toast.error('Fill in both fields');
    const { data } = await api.post('/admin/announce', announce);
    toast.success(`Announcement sent to ${data.sent} users`);
    setAnnounce({ title: '', message: '' });
  };

  const addCategory = async () => {
    if (!catForm.name) return;
    const { data } = await api.post('/categories', catForm);
    setCategories(cs => [...cs, data]);
    setCatForm({ name: '', icon: '📦' });
    toast.success('Category added');
  };

  const deleteCategory = async (id) => {
    await api.delete(`/categories/${id}`);
    setCategories(cs => cs.filter(c => c.id !== id));
    toast.success('Category deleted');
  };

  const ts = s => { try { return formatDistanceToNow(new Date(s * 1000), {addSuffix:true}); } catch { return ''; }};

  const tabs = [
    { id: 'overview', label: '📊 Overview' },
    { id: 'users', label: '👥 Users' },
    { id: 'items', label: '📦 Items' },
    { id: 'claims', label: '🤝 Claims' },
    { id: 'reports', label: '🚨 Reports' },
    { id: 'categories', label: '📂 Categories' },
    { id: 'announce', label: '📢 Announce' },
    { id: 'logs', label: '📜 Logs' },
  ];

  if (loading) return <div className="text-center py-20"><div className="text-4xl animate-spin">🔍</div></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 page-enter">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent-500 to-primary-600 flex items-center justify-center text-white text-xl">🛡️</div>
        <div>
          <h1 className="font-display font-bold text-3xl">Admin Panel</h1>
          <p className="text-gray-500 text-sm">Manage your Lost & Found platform</p>
        </div>
      </div>

      {/* Tab Nav */}
      <div className="flex gap-1 overflow-x-auto mb-6 pb-1">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${tab === t.id ? 'bg-primary-600 text-white' : 'bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === 'overview' && stats && (
        <div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {[
              { label: 'Total Users', value: stats.total_users, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50 dark:bg-blue-900/20' },
              { label: 'Lost Items', value: stats.total_lost, icon: Package, color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-900/20' },
              { label: 'Found Items', value: stats.total_found, icon: Package, color: 'text-green-600', bg: 'bg-green-50 dark:bg-green-900/20' },
              { label: 'Total Claims', value: stats.total_claims, icon: ClipboardList, color: 'text-purple-600', bg: 'bg-purple-50 dark:bg-purple-900/20' },
              { label: 'Pending Claims', value: stats.pending_claims, icon: AlertTriangle, color: 'text-yellow-600', bg: 'bg-yellow-50 dark:bg-yellow-900/20' },
              { label: 'Resolved', value: stats.resolved_items, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-900/20' },
              { label: 'Flagged Reports', value: stats.reported_items, icon: Flag, color: 'text-orange-600', bg: 'bg-orange-50 dark:bg-orange-900/20' },
            ].map(s => (
              <div key={s.label} className="card p-5">
                <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center mb-3`}>
                  <s.icon size={20} className={s.color}/>
                </div>
                <div className="text-2xl font-display font-bold">{s.value}</div>
                <div className="text-xs text-gray-500 mt-1">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="card p-5">
              <h3 className="font-semibold mb-3">Recent Items</h3>
              <div className="space-y-3">
                {stats.recent_items?.map(item => (
                  <Link key={item.id} to={`/items/${item.uuid}`} className="flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-gray-800 p-2 rounded-xl transition-colors">
                    <span className={item.type === 'lost' ? 'badge-lost' : 'badge-found'}>{item.type}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.title}</p>
                      <p className="text-xs text-gray-400">{item.user_name} · {ts(item.created_at)}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold mb-3">Recent Users</h3>
              <div className="space-y-3">
                {stats.recent_users?.map(u => (
                  <div key={u.id} className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white text-sm font-bold">{u.name?.[0]}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{u.name}</p>
                      <p className="text-xs text-gray-400">{u.email} · {ts(u.created_at)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Users */}
      {tab === 'users' && (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
                <tr>{['Name', 'Email', 'Phone', 'Items', 'Claims', 'Joined', 'Status', 'Actions'].map(h => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>)}</tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                {users.map(u => (
                  <tr key={u.id} className={u.is_blocked ? 'opacity-60' : ''}>
                    <td className="px-4 py-3 font-medium">{u.name}</td>
                    <td className="px-4 py-3 text-gray-500">{u.email}</td>
                    <td className="px-4 py-3 text-gray-500">{u.phone || '-'}</td>
                    <td className="px-4 py-3">{u.items_count}</td>
                    <td className="px-4 py-3">{u.claims_count}</td>
                    <td className="px-4 py-3 text-gray-500 whitespace-nowrap">{ts(u.created_at)}</td>
                    <td className="px-4 py-3"><span className={`text-xs px-2 py-1 rounded-full font-medium ${u.is_blocked ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>{u.is_blocked ? 'Blocked' : 'Active'}</span></td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2">
                        <button onClick={() => blockUser(u.id)} className={`text-xs px-2.5 py-1.5 rounded-lg font-medium transition-colors ${u.is_blocked ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'}`}>
                          {u.is_blocked ? 'Unblock' : 'Block'}
                        </button>
                        <button onClick={() => deleteUser(u.id)} className="text-xs px-2.5 py-1.5 rounded-lg font-medium bg-red-100 text-red-700 hover:bg-red-200 transition-colors">Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Items */}
      {tab === 'items' && (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
                <tr>{['Title', 'Type', 'Category', 'User', 'Claims', 'Status', 'Actions'].map(h => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>)}</tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                {items.map(item => (
                  <tr key={item.id}>
                    <td className="px-4 py-3"><Link to={`/items/${item.uuid}`} className="font-medium hover:text-primary-600 max-w-[200px] truncate block">{item.title}</Link></td>
                    <td className="px-4 py-3"><span className={item.type === 'lost' ? 'badge-lost' : 'badge-found'}>{item.type}</span></td>
                    <td className="px-4 py-3 text-gray-500">{item.category_name || '-'}</td>
                    <td className="px-4 py-3 text-gray-500">{item.user_name}</td>
                    <td className="px-4 py-3">{item.claims_count}</td>
                    <td className="px-4 py-3"><span className={`text-xs px-2 py-1 rounded-full font-medium capitalize ${item.status === 'active' ? 'bg-green-100 text-green-700' : item.status === 'resolved' ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'}`}>{item.status}</span></td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2">
                        {item.status === 'active' && <button onClick={() => updateItemStatus(item.id, 'resolved')} className="text-xs px-2.5 py-1.5 rounded-lg font-medium bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors">Resolve</button>}
                        {item.status !== 'removed' && <button onClick={() => updateItemStatus(item.id, 'removed')} className="text-xs px-2.5 py-1.5 rounded-lg font-medium bg-red-100 text-red-700 hover:bg-red-200 transition-colors">Remove</button>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Claims */}
      {tab === 'claims' && (
        <div className="space-y-4">
          {claims.map(c => (
            <div key={c.id} className="card p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold">{c.item_title} <span className="text-gray-400 font-normal">({c.item_type})</span></p>
                  <p className="text-sm text-gray-500 mt-1">Claimed by <strong>{c.claimant_name}</strong> ({c.claimant_email}) from owner <strong>{c.owner_name}</strong></p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">{c.description}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-semibold capitalize ${c.status === 'approved' ? 'bg-green-100 text-green-700' : c.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>{c.status}</span>
                    <span className="text-xs text-gray-400">{ts(c.created_at)}</span>
                  </div>
                </div>
                {c.status === 'pending' && (
                  <div className="flex gap-2">
                    <button onClick={() => { api.put(`/claims/${c.id}`, {status:'approved'}); setClaims(cs => cs.map(x => x.id === c.id ? {...x, status:'approved'} : x)); toast.success('Claim approved'); }} className="text-xs bg-green-100 text-green-700 hover:bg-green-200 px-3 py-1.5 rounded-lg font-medium">Approve</button>
                    <button onClick={() => { api.put(`/claims/${c.id}`, {status:'rejected'}); setClaims(cs => cs.map(x => x.id === c.id ? {...x, status:'rejected'} : x)); toast.success('Claim rejected'); }} className="text-xs bg-red-100 text-red-700 hover:bg-red-200 px-3 py-1.5 rounded-lg font-medium">Reject</button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Reports */}
      {tab === 'reports' && (
        <div className="space-y-4">
          {reports.map(r => (
            <div key={r.id} className="card p-5 flex items-start justify-between gap-4">
              <div>
                <p className="font-semibold">{r.item_title}</p>
                <p className="text-sm text-gray-500 mt-1">Reported by <strong>{r.reporter_name}</strong> · Owner: <strong>{r.owner_name}</strong></p>
                <p className="text-sm mt-1 text-red-500">{r.reason}</p>
                <span className={`text-xs px-2.5 py-1 rounded-full font-semibold mt-2 inline-block capitalize ${r.status === 'pending' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-600'}`}>{r.status}</span>
              </div>
              {r.status === 'pending' && (
                <div className="flex gap-2 flex-shrink-0">
                  <button onClick={() => handleReport(r.id, 'dismissed', null)} className="text-xs bg-gray-100 text-gray-700 hover:bg-gray-200 px-3 py-1.5 rounded-lg font-medium">Dismiss</button>
                  <button onClick={() => handleReport(r.id, 'actioned', 'remove')} className="text-xs bg-red-100 text-red-700 hover:bg-red-200 px-3 py-1.5 rounded-lg font-medium">Remove Item</button>
                </div>
              )}
            </div>
          ))}
          {reports.length === 0 && <div className="text-center py-12 text-gray-400"><div className="text-4xl mb-2">✅</div>No reports pending</div>}
        </div>
      )}

      {/* Categories */}
      {tab === 'categories' && (
        <div className="max-w-lg">
          <div className="card p-5 mb-5">
            <h3 className="font-semibold mb-3">Add Category</h3>
            <div className="flex gap-3">
              <input className="input flex-1" placeholder="Category name" value={catForm.name} onChange={e => setCatForm(f => ({...f, name: e.target.value}))}/>
              <input className="input w-20 text-center text-xl" placeholder="📦" value={catForm.icon} onChange={e => setCatForm(f => ({...f, icon: e.target.value}))}/>
              <button onClick={addCategory} className="btn-primary px-4">Add</button>
            </div>
          </div>
          <div className="space-y-2">
            {categories.map(c => (
              <div key={c.id} className="card px-4 py-3 flex items-center justify-between">
                <span className="font-medium">{c.icon} {c.name}</span>
                <button onClick={() => deleteCategory(c.id)} className="text-red-500 hover:text-red-700 p-1"><Trash2 size={15}/></button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Announce */}
      {tab === 'announce' && (
        <div className="max-w-lg card p-6">
          <h3 className="font-semibold mb-4 flex items-center gap-2"><Megaphone size={18}/>Send Announcement</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">Title</label>
              <input className="input" placeholder="Announcement title" value={announce.title} onChange={e => setAnnounce(a => ({...a, title: e.target.value}))}/>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Message</label>
              <textarea className="input min-h-[100px] resize-none" placeholder="Your message to all users..." value={announce.message} onChange={e => setAnnounce(a => ({...a, message: e.target.value}))}/>
            </div>
            <button onClick={sendAnnouncement} className="btn-primary flex items-center gap-2 w-full justify-center">
              <Megaphone size={16}/>Send to All Users
            </button>
          </div>
        </div>
      )}

      {/* Logs */}
      {tab === 'logs' && (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
                <tr>{['User', 'Action', 'Details', 'Time'].map(h => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>)}</tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                {logs.map(l => (
                  <tr key={l.id}>
                    <td className="px-4 py-3 text-gray-600">{l.user_name || 'System'}</td>
                    <td className="px-4 py-3"><span className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded font-mono">{l.action}</span></td>
                    <td className="px-4 py-3 text-gray-500 max-w-xs truncate">{l.details || '-'}</td>
                    <td className="px-4 py-3 text-gray-400 whitespace-nowrap">{ts(l.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
