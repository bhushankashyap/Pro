import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Package, ClipboardList, Bookmark, MessageCircle, Bell } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import ItemCard from '../components/ItemCard';

export default function Dashboard() {
  const { user } = useAuth();
  const [tab, setTab] = useState('my-items');
  const [myItems, setMyItems] = useState([]);
  const [myClaims, setMyClaims] = useState([]);
  const [receivedClaims, setReceivedClaims] = useState([]);
  const [bookmarks, setBookmarks] = useState([]);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const p = [
      api.get(`/items?user_id=${user.id}&limit=20`).then(r => setMyItems(r.data)),
      api.get('/claims/my').then(r => setMyClaims(r.data)),
      api.get('/claims/received').then(r => setReceivedClaims(r.data)),
      api.get('/items/user/bookmarks').then(r => setBookmarks(r.data)),
      api.get('/messages').then(r => setMessages(r.data)),
    ];
    Promise.all(p).finally(() => setLoading(false));
  }, []);

  const updateClaimStatus = async (id, status) => {
    await api.put(`/claims/${id}`, { status });
    setReceivedClaims(cs => cs.map(c => c.id === id ? {...c, status} : c));
  };

  const statusColor = { pending: 'text-yellow-600 bg-yellow-50 dark:bg-yellow-900/20', approved: 'text-green-600 bg-green-50 dark:bg-green-900/20', rejected: 'text-red-600 bg-red-50 dark:bg-red-900/20' };
  const ts = s => s ? formatDistanceToNow(new Date(s * 1000), {addSuffix: true}) : '';

  const tabs = [
    { id: 'my-items', label: 'My Items', icon: Package, count: myItems.length },
    { id: 'my-claims', label: 'My Claims', icon: ClipboardList, count: myClaims.length },
    { id: 'received-claims', label: 'Received Claims', icon: ClipboardList, count: receivedClaims.filter(c => c.status === 'pending').length },
    { id: 'bookmarks', label: 'Saved', icon: Bookmark, count: bookmarks.length },
    { id: 'messages', label: 'Messages', icon: MessageCircle, count: messages.filter(m => !m.is_read && m.receiver_id === user.id).length },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 page-enter">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-bold text-3xl">Dashboard</h1>
          <p className="text-gray-500 mt-1">Welcome back, {user.name}!</p>
        </div>
        <Link to="/items/new" className="btn-primary flex items-center gap-2"><Plus size={18}/>Report Item</Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Items Posted', value: myItems.length, icon: '📋', color: 'from-blue-400 to-blue-600' },
          { label: 'Claims Made', value: myClaims.length, icon: '🤝', color: 'from-purple-400 to-purple-600' },
          { label: 'Claims Received', value: receivedClaims.length, icon: '📥', color: 'from-orange-400 to-orange-600' },
          { label: 'Saved Items', value: bookmarks.length, icon: '❤️', color: 'from-pink-400 to-pink-600' },
        ].map(s => (
          <div key={s.label} className={`card p-5 bg-gradient-to-br ${s.color} text-white`}>
            <div className="text-3xl mb-2">{s.icon}</div>
            <div className="text-3xl font-display font-bold">{s.value}</div>
            <div className="text-sm opacity-80 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto mb-6 pb-1">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${tab === t.id ? 'bg-primary-600 text-white' : 'bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
            <t.icon size={15}/>{t.label}
            {t.count > 0 && <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold ${tab === t.id ? 'bg-white/20' : 'bg-primary-100 dark:bg-primary-900/30 text-primary-600'}`}>{t.count}</span>}
          </button>
        ))}
      </div>

      {loading ? <div className="text-center py-12 text-gray-400">Loading...</div> : (
        <>
          {/* My Items */}
          {tab === 'my-items' && (
            myItems.length === 0 ? (
              <div className="text-center py-16">
                <div className="text-5xl mb-3">📭</div>
                <p className="text-gray-500 mb-4">You haven't posted any items yet</p>
                <Link to="/items/new" className="btn-primary inline-flex items-center gap-2"><Plus size={16}/>Post Your First Item</Link>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {myItems.map(item => <ItemCard key={item.id} item={item}/>)}
              </div>
            )
          )}

          {/* My Claims */}
          {tab === 'my-claims' && (
            <div className="space-y-4">
              {myClaims.length === 0 ? <div className="text-center py-16"><div className="text-5xl mb-3">🤝</div><p className="text-gray-500">No claims submitted yet</p></div> :
                myClaims.map(c => (
                  <div key={c.id} className="card p-5 flex gap-4">
                    <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-gray-100 dark:bg-gray-800">
                      {c.item_images?.[0] ? <img src={`/uploads/${c.item_images[0]}`} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center text-2xl">📦</div>}
                    </div>
                    <div className="flex-1 min-w-0">
                      <Link to={`/items/${c.item_uuid}`} className="font-semibold hover:text-primary-600 truncate block">{c.item_title}</Link>
                      <p className="text-sm text-gray-500 mt-0.5 line-clamp-2">{c.description}</p>
                      <div className="flex items-center gap-3 mt-2">
                        <span className={`text-xs px-2.5 py-1 rounded-full font-semibold capitalize ${statusColor[c.status]}`}>{c.status}</span>
                        <span className="text-xs text-gray-400">{ts(c.created_at)}</span>
                      </div>
                      {c.admin_note && <p className="text-xs text-gray-500 mt-2 p-2 bg-gray-50 dark:bg-gray-800 rounded-lg">Note: {c.admin_note}</p>}
                    </div>
                  </div>
                ))
              }
            </div>
          )}

          {/* Received Claims */}
          {tab === 'received-claims' && (
            <div className="space-y-4">
              {receivedClaims.length === 0 ? <div className="text-center py-16"><div className="text-5xl mb-3">📥</div><p className="text-gray-500">No claims received yet</p></div> :
                receivedClaims.map(c => (
                  <div key={c.id} className="card p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <Link to={`/items/${c.item_uuid}`} className="font-semibold hover:text-primary-600">{c.item_title}</Link>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white text-xs font-bold">{c.claimant_name?.[0]}</div>
                          <span className="text-sm text-gray-600 dark:text-gray-400">{c.claimant_name}</span>
                          <span className="text-xs text-gray-400">· {c.claimant_email}</span>
                          {c.claimant_phone && <span className="text-xs text-gray-400">· {c.claimant_phone}</span>}
                        </div>
                        <p className="text-sm text-gray-500 mt-2">{c.description}</p>
                        <div className="flex items-center gap-3 mt-2">
                          <span className={`text-xs px-2.5 py-1 rounded-full font-semibold capitalize ${statusColor[c.status]}`}>{c.status}</span>
                          <span className="text-xs text-gray-400">{ts(c.created_at)}</span>
                        </div>
                        {c.proof_image && <a href={`/uploads/${c.proof_image}`} target="_blank" className="text-xs text-primary-600 hover:underline mt-1 block">View proof image →</a>}
                      </div>
                      {c.status === 'pending' && (
                        <div className="flex gap-2 flex-shrink-0">
                          <button onClick={() => updateClaimStatus(c.id, 'approved')} className="text-xs bg-green-100 text-green-700 hover:bg-green-200 px-3 py-1.5 rounded-lg font-medium transition-colors">Approve</button>
                          <button onClick={() => updateClaimStatus(c.id, 'rejected')} className="text-xs bg-red-100 text-red-700 hover:bg-red-200 px-3 py-1.5 rounded-lg font-medium transition-colors">Reject</button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              }
            </div>
          )}

          {/* Bookmarks */}
          {tab === 'bookmarks' && (
            bookmarks.length === 0 ? <div className="text-center py-16"><div className="text-5xl mb-3">🔖</div><p className="text-gray-500">No saved items yet</p></div> :
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {bookmarks.map(item => <ItemCard key={item.id} item={item}/>)}
            </div>
          )}

          {/* Messages */}
          {tab === 'messages' && (
            <div className="space-y-3">
              {messages.length === 0 ? <div className="text-center py-16"><div className="text-5xl mb-3">💬</div><p className="text-gray-500">No messages yet</p></div> :
                messages.map(m => (
                  <div key={m.id} className={`card p-4 flex gap-3 ${!m.is_read && m.receiver_id === user.id ? 'border-primary-200 dark:border-primary-800' : ''}`}>
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                      {(m.receiver_id === user.id ? m.sender_name : m.receiver_name)?.[0]?.toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{m.receiver_id === user.id ? m.sender_name : m.receiver_name}</span>
                        <span className="text-xs text-gray-400">{ts(m.created_at)}</span>
                      </div>
                      <p className="text-sm text-gray-500 mt-0.5 truncate">{m.content}</p>
                      {m.item_title && <span className="text-xs text-primary-600">re: {m.item_title}</span>}
                    </div>
                    {!m.is_read && m.receiver_id === user.id && <div className="w-2 h-2 bg-primary-500 rounded-full flex-shrink-0 mt-2"/>}
                  </div>
                ))
              }
            </div>
          )}
        </>
      )}
    </div>
  );
}
